void proc(struct ele *up) {
    up -> next -> y[0] = * (up -> e1.p) + up -> e1.x;
}
